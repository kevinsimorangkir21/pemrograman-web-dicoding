@extends('layouts.admin.app')

@section('title', 'Detail Prodi')

@section('content')

  <!--Detail Prodi-->
  <div class="col-lg-12 col-lg-12 form-wrapper" id="detail-prodi">
    <div class="card">
    <div class="card-header">
    <h4 class="card-title">Detail Data Prodi</h4>
    </div>
    <div class="card-body">
    @if(auth()->user()->roles_id == 1)
        <form method="POST" action="{{ route('super.prodi.show',$prodi->id) }}" enctype='multipart/form-data'>
    @elseif(auth()->user()->roles_id == 2)
        <form method="POST" action="{{ route('admin.prodi.show',$prodi->id) }}" enctype='multipart/form-data'>
    @elseif(auth()->user()->roles_id == 3)
        <form method="POST" action="{{ route('himpunans.prodi.show',$prodi->id) }}" enctype='multipart/form-data'>
    @endif
        @csrf
      @method('PUT')
      <input type="hidden" value="{{ $prodi->id }}" name="id">
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Nama Prodi</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" placeholder="Nama Prodi" name="namaLengkap" id="namaprodi" value="{{ $prodi->namaLengkap }}" disabled>
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Nama Singkat</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" placeholder="Nama Prodi" name="namaSingkat" id="namaprodi" value="{{ $prodi->namaSingkat }}" disabled>
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Kepala Prodi</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" placeholder="Nama Kepala Prodi" name="kepalaProdi" id="namakaprodi" value="{{ $prodi->kepalaProdi }}" disabled>
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Akreditasi</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" placeholder="Akreditasi" name="akreditasi" id="akreditasi" value="{{ $prodi->akreditasi }}" disabled>
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Ruang Prodi</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" placeholder="Ruang Prodi" name="ruangProdi" id="ruangprodi" value="{{ $prodi->ruangProdi }}" disabled>
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Tahun Berdiri</label>
          <div class="col-sm-9">
            <input type="number" class="form-control" name="tahunBerdiri" id="tahunBerdiri" value="{{ $prodi->tahunBerdiri }}" disabled>
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Jumlah Mahasiswa</label>
          <div class="col-sm-9">
            <input type="text" class="form-control" placeholder="Jumlah Mahasiswa" name="jumlahMahasiswa" id="kodeWarna" value="{{ $prodi->jumlahMahasiswa }}"  disabled>
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Visi</label>
          <div class="col-sm-9">
            <textarea class="form-control custom-txt-area visi" placeholder="Visi" name="visi" id="visi" value="{{ $prodi->visi }}" disabled>{{ $prodi->visi }}</textarea>
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Misi</label>
          <div class="col-sm-9">
            <textarea class="form-control custom-txt-area misi" placeholder="Misi" name="misi" id="misi" value="{{ $prodi->misi }}" disabled>{{ $prodi->misi }}</textarea>
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Logo</label>
          <div class="col-sm-9">
           <img src="{{ asset('assets/logoProdi/') }}/{{ $prodi->logo }}" alt="logo" width="75px">
          </div>
        </div>
        <div class="mb-3 row">
          <label class="col-sm-3 col-form-label">Tentang Kami</label>
          <div class="col-sm-9 ">
            <textarea class="form-control custom-txt-area" placeholder="Tentang Kami" name="deskripsi" id="tentangkami" value="{{ $prodi->deskripsi }}" disabled>{{ $prodi->deskripsi }}</textarea>
          </div>
        </div>
          <div class="mb-3 row">
            <label class="col-sm-3 col-form-label">Prestasi</label>
            <div class="col-sm-9 mb-3">
              <textarea class="form-control custom-txt-area misi" placeholder="Tahun 2020" name="prestasi1" id="prestasi1" value="{{ $prodi->prestasi1 }}" disabled>{{ $prodi->prestasi1 }}</textarea>
              <textarea class="form-control custom-txt-area misi" placeholder="Tahun 2021" name="prestasi2" id="prestasi2" value="{{ $prodi->prestasi2 }}"  disabled>{{ $prodi->prestasi2 }}</textarea>
              <textarea class="form-control custom-txt-area misi" placeholder="Tahun 2022" name="prestasi3" id="prestasi3" value="{{ $prodi->prestasi3}}"  disabled>{{ $prodi->prestasi3 }}</textarea>
            </div>
        </div>
        <div class="mb-3 row">
            <label class="col-sm-3 col-form-label">Jurusan</label>
              <div class="col-sm-9">
              <select style="width:100px;" selected class="selected" name="jurusan_id" value="{{ $prodi->jurusan_id }}" disabled>
                <option value="1" >JTIK</option>
                <option value="2">JTIP</option>
                <option value="3">JS</option>
              </select>
            </div>
          </div>
          <div class="mb-3 row">
            <div class="col-sm-9">
              <a>
                @if(auth()->user()->roles_id == 1)
                    <a class="btn btn-primary" href="{{ route('super.prodi.index') }}">Kembali</a>
                @elseif(auth()->user()->roles_id == 2)
                    <a class="btn btn-primary" href="{{ route('admin.prodi.index') }}">Kembali</a>
                @elseif(auth()->user()->roles_id == 3)
                    <a class="btn btn-primary" href="{{ route('himpunans.prodi.index') }}">Kembali</a>
                @endif
              </a>
            </div>
        </div><br><br><br>
        </form>
      </div>
    </div>
  </div>
  <!--Detail Prodi-->

@endsection
