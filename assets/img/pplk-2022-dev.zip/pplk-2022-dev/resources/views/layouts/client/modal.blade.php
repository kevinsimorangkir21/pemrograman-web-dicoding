<script>
    $("#myModal").on('hidden.bs.modal', function (e) {
        $("#myModal .modal-dialog");
    });
    $(document).ready(function(){
        $("#modal-sponsor").modal('show');
    });    
</script>