@extends('layouts.client.app')

<!-- TITLE -->
@section('title', 'Template')

@section('style')
    <!-- STYLES -->
    <link rel="stylesheet" href="{{ asset('assets/css/GANTI.css') }}">
@endsection

@section('content')
    <!-- CONTENT -->
    <section></section>
@endsection

@section('script')
    <!-- SCRIPTS -->
    <script></script>
@endsection
